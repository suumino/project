from django import forms

class Sequence(forms.Form):
    sequence = forms.CharField(label='sequence')
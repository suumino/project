def pre_pro(sequence):
    n = '0123456789'
    for i in sequence:
        if i in n: sequence = sequence.replace(i, "")
    sequence = sequence.upper()
    sequence = sequence.replace(" ", "")
    return sequence

def forword(sequence):
    for_seq = sequence[:sequence.index('[')]
    for_prm = []
    Tm = []
    Gc = []
    i = 0

    while i < len(for_seq)-20:   
        a = for_seq[i:i+20]
        gc = (a.count('G') + a.count('C')) / (a.count('A') + a.count('T') + a.count('G') + a.count('C')) * 100
        tm = (4*(a.count('G')+a.count('C'))) + (2*(a.count('A')+a.count('T'))) 
            
        if 40 <= tm <= 60 and 50 <= gc <= 60: 
            for_prm.append(a)
            Tm.append(tm)
            Gc.append(gc)
            i += 4
        i += 1
    return for_prm[0], Tm[0], Gc[0]

def for_prm(sequence):
  forw = forword(sequence)
  return forw[0]

def for_Tm(sequence):
  forw = forword(sequence)
  return forw[1]
  
def for_Gc(sequence):
  forw = forword(sequence)
  return forw[2]

def reverse(sequence):
    rev_seq = sequence[sequence.index(']')+1:]
    
    pre_prm = []
    Tm = []
    Gc = []
    i = 0
    
    while i < len(rev_seq)-20:   
        a = rev_seq[i:i+20]
        gc = (a.count('G') + a.count('C')) / (a.count('A') + a.count('T') + a.count('G') + a.count('C')) * 100
        tm = (4*(a.count('G')+a.count('C'))) + (2*(a.count('A')+a.count('T')))   

        if 40 <= tm <= 60 and 50 <= gc <= 60: 
            pre_prm.append(a)
            Tm.append(tm)
            Gc.append(gc)
            i += 4
        i += 1

    rev_prm =  []
    for i in range(len(pre_prm)):
        rev_prm.append('')
        for j in range(len(pre_prm[i])):
            if pre_prm[i][j] == 'C':  rev_prm[i] += ('G')
            elif pre_prm[i][j] == 'G':  rev_prm[i] += ('C')
            elif pre_prm[i][j] == 'A':  rev_prm[i] += ('T')
            elif pre_prm[i][j] == 'T':  rev_prm[i] += ('A')
        rev_prm[i] = ''.join(reversed(rev_prm[i]))
    

    return rev_prm[0], Tm[0], Gc[0]

def rev_prm(sequence):
  rev = reverse(sequence)
  return rev[0]

def rev_Tm(sequence):
  rev = reverse(sequence)
  return rev[1]
  
def rev_Gc(sequence):
  rev = reverse(sequence)
  return rev[2]

    


def rev_mm(sequence):
    rev_seq = sequence[sequence.index(']')+1:]
    
    pre_prm = []
    Tm = []
    Gc = []
    i = 0
    
    while i < len(rev_seq)-20:   
        a = rev_seq[i:i+20]
        gc = (a.count('G') + a.count('C')) / (a.count('A') + a.count('T') + a.count('G') + a.count('C')) * 100
        tm = (4*(a.count('G')+a.count('C'))) + (2*(a.count('A')+a.count('T')))   

        if 40 <= tm <= 60 and 50 <= gc <= 60: 
            pre_prm.append(a)
            Tm.append(tm)
            Gc.append(gc)
            i += 4
        i += 1
    return pre_prm[0]


def cut(forword, reverse, sequence):
    target = sequence[sequence.index('[')+1:sequence.index(']')]
    for i in range(len(sequence)-20):
        a = sequence[i:i+20]
        if a == forword: 
            m_forword = sequence[:i]
            forword_m = sequence[i+20:sequence.index('[')]
            m = i
        if a == reverse : 
            m_reverse = sequence[sequence.index(']')+1:i]
            reverse_m = sequence[i+20:]
            n = i+20
    return m_forword, forword, forword_m, target, m_reverse, reverse, reverse_m, n-m-2
        
def m_forword(forword, reverse, sequence):
    a = cut(forword, reverse, sequence)
    return a[0]
def cut_forword(forword, reverse, sequence):
    a = cut(forword, reverse, sequence)
    return a[1]
def forword_m(forword, reverse, sequence):
    a = cut(forword, reverse, sequence)
    return a[2]
def target(forword, reverse, sequence):
    a = cut(forword, reverse, sequence)
    return a[3]
def m_reverse(forword, reverse, sequence):
    a = cut(forword, reverse, sequence)
    return a[4]
def cut_reverse(forword, reverse, sequence):
    a = cut(forword, reverse, sequence)
    return a[5]
def reverse_m(forword, reverse, sequence):
    a = cut(forword, reverse, sequence)
    return a[6]
def length(forword, reverse, sequence):
    a = cut(forword, reverse, sequence)
    return a[7]




    
def target_graph(sequence):
    import matplotlib.pyplot as plt
    import numpy as np

    sequence = sequence[sequence.index('[')+1:sequence.index(']')]
    A = sequence.count('A')
    T = sequence.count('T')
    G = sequence.count('G')
    C = sequence.count('C')
    x = np.arange(4)
    years = ['A', 'T', 'G', 'C']
    values = [A, T, G, C]

    plt.bar(x, values, width=0.6, align='edge', color='red', edgecolor='black', linewidth=3, tick_label=years, log=True)
    plt.savefig('templates/mysite/graph.png')
    return A, T, G, C

def A(sequence):
    b = target_graph(sequence)
    return b[0]
def T(sequence):
    b = target_graph(sequence)
    return b[1]
def G(sequence):
    b = target_graph(sequence)
    return b[2]
def C(sequence):
    b = target_graph(sequence)
    return b[3]
from django.shortcuts import render
from django.http import HttpResponse
from . import primer
from . import forms


def base(request):
    # form = forms.Sequence()
    # sequence = {'form' : form,}
    return render(request, 'mysite/base.html')


def result(request):
    # if request.method == "POST":
    #     form = forms.Sequence(request.POST)
    #     if form.is_valid():
    #         form.cleaned_data
    #         return redirect('pybo:result')
    # else:
    #     form = forms.Sequence()

    # sequence = {
    #     'form' : form,
    # }
    sequence = request.GET.get('sequence')
    # sequence = {'target':sequence}
    # sequence = str(sequence)
    

    # form = forms.Sequence()
    # sequence = {'form' : form, },
    # sequence = '1 agataacctg gaattgatat ttgatttttt tgaggaagat ctcattgaac atgtagttca61 gggagatgcc cttcctggac atgtagggac agcatgcctc ttatcatcca ccattgctga 121 gagtgggaag agcgctggaa ttctcactct tcccatcatg agcaaaaatt ccagaaaaac 181 aatatgcaaa[ gtgagaggtg actatataat tattaagcca ttaccaggat acaattgtga 241 catgaagtct tcattttcca agtattggaa gccaacaaca ccattggatg ttggacatcg 301 aggtgcatgg] aattctacaa caactgctca gcttgctaaa gttcaagaaa atactattgc 361 ttctttaaga aatgctgcta gtcatggtgc agactttgta gaatttgatg tacatctttc 421 aaaagatttt gtgactgtgg cgtatcatga tctcacctgt tgtttgacaa tgaaaaaga 481 atttgatgct gatccagttg aattatttga aactccagta aaggaattaa catttgacc 541 actccagttg ttaaagcttg ctcatgtgac tgcc'
    
    sequence = str(primer.pre_pro(sequence))
    for_prm = str(primer.for_prm(sequence))
    for_Tm = str(primer.for_Tm(sequence))
    for_Gc = str(primer.for_Gc(sequence))

    rev_prm = str(primer.rev_prm(sequence))
    rev_Tm = str(primer.rev_Tm(sequence))
    rev_Gc = str(primer.rev_Gc(sequence))

    m_forword = str(primer.m_forword (for_prm, primer.rev_mm(sequence), sequence))
    cut_forword = str(primer.cut_forword(for_prm, primer.rev_mm(sequence), sequence))
    forword_m = str(primer.forword_m(for_prm, primer.rev_mm(sequence), sequence))
    target = str(primer.target(for_prm, primer.rev_mm(sequence), sequence))
    m_reverse = str(primer.m_reverse(for_prm, primer.rev_mm(sequence), sequence))
    cut_reverse = str(primer.cut_reverse(for_prm, primer.rev_mm(sequence), sequence))
    reverse_m = str(primer.reverse_m(for_prm, primer.rev_mm(sequence), sequence))
    length = str(primer.length(for_prm, primer.rev_mm(sequence), sequence))

    # primer.target_graph(sequence)
    A = int(primer.A(sequence))
    T = int(primer.T(sequence))
    G = int(primer.G(sequence))
    C = int(primer.C(sequence))
    return render(request, 'mysite/result.html',
                    {'the_forprm':for_prm, 
                    'the_forTm':for_Tm,
                    'the_forGc':for_Gc,
                    'the_revprm':rev_prm, 
                    'the_revTm':rev_Tm,
                    'the_revGc':rev_Gc,
                    'm_forword':m_forword, 
                    'cut_forword':cut_forword,
                    'forword_m':forword_m,
                    'target':target,
                    'm_reverse':m_reverse,
                    'cut_reverse':cut_reverse,
                    'reverse_m':reverse_m,
                    'length':length,
                    'A':A, 
                    'T':T,
                    'G':G,
                    'C':C
                    }
                    )

    return render(request, 'mysite/result.html', 
                    sequence)

def explain(request):
    """
    primer design 기준에 대해 설명
    """
    return render(request, 'mysite/explain.html')

def sample(request):
    """
    primer sequence 샘플
    """
    return render(request, 'mysite/sample.html')


if __name__ == '__main__':
    app.run(debug=True)

package com.godcoder.myhome.repository;

import com.godcoder.myhome.model.Sandwich;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SandwichRepository extends JpaRepository<Sandwich, Long> {
}

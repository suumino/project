package com.godcoder.myhome.repository;

import com.godcoder.myhome.model.Cheese;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CheeseRepository extends JpaRepository<Cheese, Long>{
    
}

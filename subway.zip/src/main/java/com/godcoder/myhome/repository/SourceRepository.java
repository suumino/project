package com.godcoder.myhome.repository;

import com.godcoder.myhome.model.Source;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SourceRepository extends JpaRepository<Source, Long>{
    
}

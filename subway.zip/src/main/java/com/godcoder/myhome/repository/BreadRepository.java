package com.godcoder.myhome.repository;

import com.godcoder.myhome.model.Bread;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BreadRepository extends JpaRepository<Bread, Long>{
    
}

package com.godcoder.myhome.repository;

import com.godcoder.myhome.model.Place;

import org.springframework.data.jpa.repository.JpaRepository;

public interface placeRepository extends JpaRepository<Place, Long>{
    
}

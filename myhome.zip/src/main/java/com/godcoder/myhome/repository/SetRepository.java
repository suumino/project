package com.godcoder.myhome.repository;

import com.godcoder.myhome.model.Set;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SetRepository extends JpaRepository<Set, Long>{
    
}


package com.godcoder.myhome.controller;

import java.util.List;

// import javax.servlet.http.HttpServletRequest;

import com.godcoder.myhome.model.Bread;
import com.godcoder.myhome.model.Cheese;
import com.godcoder.myhome.model.Place;
import com.godcoder.myhome.model.Sandwich;
import com.godcoder.myhome.model.Set;
import com.godcoder.myhome.model.Source;
import com.godcoder.myhome.model.Vegetable;
import com.godcoder.myhome.repository.BreadRepository;
import com.godcoder.myhome.repository.CheeseRepository;
import com.godcoder.myhome.repository.SandwichRepository;
import com.godcoder.myhome.repository.SetRepository;
import com.godcoder.myhome.repository.SourceRepository;
import com.godcoder.myhome.repository.VegetableRepository;
import com.godcoder.myhome.repository.placeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.ModelAttribute;
// import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam;
// import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/menu")
public class MenuController {
    
    @Autowired
    private placeRepository placeRepository;

    @Autowired
    private SandwichRepository sandwichRepository;

    @Autowired
    private BreadRepository breadRepository;

    @Autowired
    private VegetableRepository vegetableRepository;

    @Autowired
    private CheeseRepository cheeseRepository;

    @Autowired
    private SourceRepository sourceRepository;

    @Autowired
    private SetRepository setRepository;

    
    @GetMapping("/sandwich")
    public String sandwich() {
        return "menu/sandwich";
    }

    @GetMapping("/bread")
    public String bread() {
        return "menu/bread";
    }

    @GetMapping("/vegetable")
    public String vegetable() {
        return "menu/vegetable";
    }

    @GetMapping("/cheese")
    public String cheese() {
        return "menu/cheese";
    }








    // @RequestMapping("/cheese")
    // public String cheeseSubmit(HttpServletRequest httpServletRequest, Model model) {
    //     String cheese = httpServletRequest.getParameter("cheese")
    //     model.addAttribute("cheese", cheese);
    //     return "menu/cheese";
    // }
 


    // @GetMapping("/cheese")
    // public String cheese(Model model) {
    //     model.addAttribute("cheese", new Cheese());
    //     return "menu/cheese";
    // }

    // @PostMapping("/cheese")
    // public String cheeseSubmit(@ModelAttribute Cheese cheese) {
    //     cheeseRepository.save(cheese);
    //     return "redirect:menu/cheese";
    // }









    @GetMapping("/source")
    public String source() {
        return "menu/source";
    }

    @GetMapping("/set")
    public String set() {
        return "menu/set";
    }

    @GetMapping("/order")
    public String order(Model model) {
        List<Place> places = placeRepository.findAll();
        model.addAttribute("places", places);

        List<Sandwich> sandwichs = sandwichRepository.findAll();
        model.addAttribute("sandwichs", sandwichs);

        List<Bread> breads = breadRepository.findAll();
        model.addAttribute("breads", breads);
        
        List<Vegetable> vegetables = vegetableRepository.findAll();
        model.addAttribute("vegetables", vegetables);
        
        List<Cheese> cheeses = cheeseRepository.findAll();
        model.addAttribute("cheeses", cheeses);
        
        List<Source> sources = sourceRepository.findAll();
        model.addAttribute("sources", sources);
        
        // List<Set> sets = setRepository.findAll();
        // model.addAttribute("sets", sets);

        return "menu/order";
    }

    @GetMapping("/end")
    public String end() {
        return "menu/end";
    }
}
